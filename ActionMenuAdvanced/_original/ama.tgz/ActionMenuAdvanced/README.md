# Action Menu Advanced

Eigene Version des [Action Menu](https://github.com/dakyneko/DakyModsCVR/tree/main/ActionMenu) von daky für ChilloutVR, umgebaut von Inazumanotenshi

## Geplante Änderungen

- Menü skaliert mit der Avatar-Größe, in VR und am Desktop, auch live beim Avatar-Scaling
- Neues Hexagon-Design im ChilloutVR-UI-Look
- Parameter, die außerhalb des Menüs geändert werden, werden im Menü übernommen
- Eingabe von Float-Werten

## Bauen

- Visual Studio 2022 mit „.NET-Desktopentwicklung"
- `ActionMenuAdvanced.sln` öffnen und bauen
- Der Pfad zu ChilloutVR steht in `Directory.Build.props` (oder Umgebungsvariable `CVRPATH`)
- Nach dem Build wird `ActionMenuAdvanced.dll` automatisch in den `Mods`-Ordner kopiert
- Die originale `ActionMenu.dll` muss aus dem `Mods`-Ordner raus, sonst laufen beide gleichzeitig

## Lizenz

GPL-3.0, wie das Original. Ursprünglicher Code © daky (dakyneko), siehe `LICENSE.txt`
